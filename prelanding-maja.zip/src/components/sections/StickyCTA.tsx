import React from 'react'

const StickyCTA: React.FC = () => {
  // Komponent został wyłączony - okienko "Maja Online teraz" zostało usunięte
  return null
}

export default StickyCTA
